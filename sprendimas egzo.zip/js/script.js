showTopRated(movies);

function getTopRated(a) {
    let p = 0;
    let index;

    for (let i = 0; i < a.length; i++)
        if (p < a[i].popularity) {
            p = a[i].popularity;
            index = i;
        }


    return a[index];
};

function showTopRated(a) {
    let movie = getTopRated(a);
    let h = '';

    h += '<img src="https://image.tmdb.org/t/p/w300_and_h450_bestv2' + movie.poster_path + '" alt="Movie Poster"><br>';
    h += '<strong>Filmo pavadinimas: </strong>' + movie.title + '<br/>';
    h += '<strong>Metai: </strong>' + movie.release_date.substring(0, 4) + '<br/>';
    h += '<strong>Filmo aprasymas: </strong>' + movie.overview + '<br/>';

    $('#top').html(h);

};

$('#filter').click(function () {
    let filterYear = $('#metai').val();
    let years = [];
    for (let i = 0; i < movies.length; i++) {
        let d = new Date(movies[i].release_date);
        years[i] = d.getFullYear()
    }

    let filteredMovies = [];
    if (filterYear != 'visi') {
        for (let i = 0; i < movies.length; i++) {
            if (filterYear == years[i])
                filteredMovies.push(movies[i]);
        }

    } else {
        filteredMovies = movies;
    }

    let h = '';
    for (let i = 0; i < filteredMovies.length; i++) {
        h += '<div class="all-movies"><div class="row"><div class="col-sm-4"><img src="https://image.tmdb.org/t/p/w300_and_h450_bestv2' + filteredMovies[i].poster_path + '" alt="Movie Poster"></div>';
        h += '<div class="col-sm-8 text"><strong>Filmo pavadinimas: </strong>' + filteredMovies[i].title+'<br/>';
        h += '<strong>Filmo aprasymas: </strong><br>' + filteredMovies[i].overview + '<br/></div><div class="divider"></div></div></div>';

    }

    $('#movies').html(h);
});